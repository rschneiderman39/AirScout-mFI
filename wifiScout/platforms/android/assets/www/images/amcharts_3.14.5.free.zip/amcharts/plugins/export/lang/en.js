AmCharts.translations[ "export" ][ "en" ] = {
	"fallback.save.text": "CTRL + C to copy the data into the clipboard.",
	"fallback.save.image": "Rightclick -> Save picture as... to save the image.",
	"capturing.delayed.menu.label": "{{duration}}",
	"capturing.delayed.menu.title": "Click to cancel"
}