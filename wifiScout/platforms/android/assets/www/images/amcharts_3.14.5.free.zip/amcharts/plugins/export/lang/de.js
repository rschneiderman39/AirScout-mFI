AmCharts.translations[ "export" ][ "de" ] = {
	"fallback.save.text": "CTRL + C um die Daten in die Zwischenablage zu kopieren.",
	"fallback.save.image": "Rechtsklick -> Bild speichern unter... um das Bild zu speichern.",
	"capturing.delayed.menu.label": "{{duration}}",
	"capturing.delayed.menu.title": "Klicken zum Abbrechen."
}