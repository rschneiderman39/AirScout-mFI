AmCharts.translations[ "export" ][ "lt" ] = {
	"fallback.save.text": "Spauskite CTRL + C jei norite nukopijuoti paveiksliuką.",
	"fallback.save.image": "Spragtelkite dešinį klavišą ir pasirinkite \"Save picture as...\" jei norite išsaugoti paveiksliuką.",
	"capturing.delayed.menu.label": "{{duration}}",
	"capturing.delayed.menu.title": "Nutraukti"
}